from flask import Flask
app = Flask(__name__)
app.secret_key = "*U5bz4:Dm&0X,Ul4(m4J~qP6"